/**
 * 
 */
/**
 * 
 */
module Tetris {
	requires java.desktop;
}