package lyon1.tetris.VueControleur;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Point;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.Border;

import lyon1.tetris.Modele.GrilleSimple;
import lyon1.tetris.Modele.Piece.Piece;



public class VueGrilleV1 extends JPanel implements Observer {
    JPanel[][] tab;
    GrilleSimple modele;

    public VueGrilleV1(GrilleSimple _modele) {
        modele = _modele;
        setLayout(new GridLayout(modele.TAILLE, modele.TAILLE));
        Border blackline = BorderFactory.createLineBorder(Color.black,1);
        setBorder(blackline);
        tab = new JPanel[modele.TAILLE][modele.TAILLE];

        for(int j = 0; j<modele.TAILLE;j++){
            for (int i = 0; i < modele.TAILLE; i++) {
                JPanel caseG = new JPanel();
                tab[i][j] = caseG;
                caseG.setBorder(blackline);
                add(caseG);
            }
        }

    }

    @Override
    public void update(Observable o, Object arg) {
        for(int i = 0; i<modele.TAILLE;i++){
            for (int j = 0; j < modele.TAILLE; j++) {

                tab[i][j].setBackground(Color.white);

            }
        }
        
        Piece pieceCourante = modele.getPieceCourante();
        Point[] blocs = pieceCourante.getBlocs();
        Color couleur = pieceCourante.getCouleur();
        
        //Point[] blocs = modele.getPieceCourante().getBlocs();
        
        for (Point bloc : blocs) {
        	 tab[bloc.x][bloc.y].setBackground(couleur);
        
        //tab[modele.getPieceCourante().getx()][modele.getPieceCourante().gety()].setBackground(Color.BLUE);
}

    }
}
