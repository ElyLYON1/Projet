package lyon1.tetris.Modele;

import java.awt.Point;
import java.util.Observable;
import java.util.Random;

import lyon1.tetris.Modele.Piece.Piece;
import lyon1.tetris.Modele.Piece.PieceI;
import lyon1.tetris.Modele.Piece.PieceJ;
import lyon1.tetris.Modele.Piece.PieceL;
import lyon1.tetris.Modele.Piece.PieceO;
import lyon1.tetris.Modele.Piece.PieceS;
import lyon1.tetris.Modele.Piece.PieceT;
import lyon1.tetris.Modele.Piece.PieceZ;

public class GrilleSimple extends Observable implements Runnable {

	public final int TAILLE = 20;

	private Piece pieceCourante;
	//Point[] blocs = pieceCourante.getBlocs();
	//private Random random = new Random();
	
	public GrilleSimple() {

		pieceCourante = new PieceO();
		new OrdonnanceurSimple(this).start(); // pour changer le temps de pause, garder la référence de l'ordonnanceur

	}

	public void action() {
		pieceCourante.descendre();

	}

	public boolean validationPosition(int _nextX, int _nextY) {
		return (_nextY >= 0 && _nextY < TAILLE);
	}

	public void run() {

		pieceCourante.descendre();
		setChanged(); // setChanged() + notifyObservers() : notification de la vue pour le
						// rafraichissement
		notifyObservers();

	}

	public Piece getPieceCourante() {
		return pieceCourante;
	}

	/*public boolean collisionBas() {

		for (Point bloc : blocs) {
			int nextY = bloc.y + 1;

			// Vérifier si le bloc dépasse la limite inférieure de la grille
			if (nextY >= TAILLE) {
				return true; // Collision détectée
			}

			// Vérifier si le bloc entre en collision avec une autre pièce déjà présente
			if (!validationPosition(bloc.x, nextY)) {
				return true; // Collision avec une autre pièce détectée
			}
		}

		return false; // Aucune collision détectée
	}*/

	// Vérifier si la pièce courante touche le côté droit de la grille
	/*public boolean collisionDroite() {

		for (Point bloc : blocs) {
			int nextX = bloc.x + 1;

			// Vérifier si le bloc dépasse la limite du côté droit de la grille
			if (nextX >= TAILLE) {
				return true; // Collision détectée
			}

			// Vérifier si le bloc entre en collision avec une autre pièce déjà présente
			if (!validationPosition(nextX, bloc.y)) {
				return true; // Collision avec une autre pièce détectée
			}
		}

		return false; // Aucune collision détectée
	}*/

	// Vérifier si la pièce courante touche le côté gauche de la grille
	/*public boolean collisionGauche() {

		for (Point bloc : blocs) {
			int nextX = bloc.x - 1;
			// Vérifier si le bloc dépasse la limite du côté gauche de la grille

			if (nextX < 0) {
				return true;// Coliision détectée
			}
			// Vérifier si le bloc entre en collision avec une autre pièce déjà présente
			if (!validationPosition(nextX, bloc.y)) {
				return true; // Collision avec une autre pièce détectée
			}

		}

		return false; // Aucune collision détectée
	}*/

	// Utilisez les coordonnées de la pièce pour détecter la collision
	/*public boolean collisionPiece() {

		// Parcourir tous les blocs de la pièce courante
		for (Point bloc : blocs) {
			int xCourant = bloc.x;
			int yCourant = bloc.y;

			// Vérifier si le bloc de la pièce courante entre en collision avec une autre
			// pièce déjà présente
			if (!validationPosition(xCourant, yCourant)) {
				return true; // Collision détectée
			}

		}
		return false;// Aucune collision détection

	}
*/
		    

		   /* public void genererNouvellePiece() {
		    	// Choisir une nouvelle pièce de manière aléatoire parmi les types disponibles
		        int pieceIndex = random.nextInt(TYPES_DE_PIECES.length); // NOMBRE_DE_TYPES_DE_PIECES est le nombre total de types de pièces
		        pieceCourante = TYPES_DE_PIECES[pieceIndex];

		        // Mise à jour de la grille avec les coordonnées de la pièce courante
		      	    for (Point bloc : blocs) {
		            int x = pieceCourante.getBlocs() + bloc.x;
		            int y = pieceCourante.getBlocs() + bloc.y;
		            // Mettez à jour la grille avec la couleur de la pièce
		            // ou toute autre information que vous utilisez pour représenter une pièce dans la grille
		            // par exemple, grille[x][y] = pieceCourante.getCouleur();
		        }

		        // Vous pouvez également vérifier si la nouvelle pièce entre en collision immédiatement
		        // après la génération et prendre des mesures supplémentaires si nécessaire.
		    }

		    // ...
}

}*/

}
