package lyon1.tetris.Modele.Piece;

import java.awt.Color;
import java.awt.Point;

public class PieceT extends Piece{
	
	public PieceT() {
		super(Color.MAGENTA);
		blocs=new Point[] {new Point(0,0),new Point(1,0), new Point(1,1),new Point(2,0)};
	}

	@Override
	public void deplacerGauche() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deplacerDroite() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void descendre() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rotation() {
		// TODO Auto-generated method stub
		
	}

}
