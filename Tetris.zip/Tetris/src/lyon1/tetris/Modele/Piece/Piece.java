package lyon1.tetris.Modele.Piece;

import java.awt.Color;
import java.awt.Point;

public abstract class Piece {

	protected Point[] blocs;//Les blocs qui composent la piece
	protected Color couleur;//La couleur de la piece
	
	
	
	public Piece(Color couleur) {
        this.couleur = couleur;
          
    }

    public Point[] getBlocs() {
        return blocs;
    }
    
    public Color getCouleur() {
        return couleur;
    }
    
   
    
    
    // Méthodes pour déplacer la pièce (gauche, droite, bas)
    public abstract void deplacerGauche();

    public abstract void deplacerDroite();

    public abstract void descendre();

    // Méthode pour effectuer une rotation de la pièce
    public abstract void rotation();

	




	
	
	
}
