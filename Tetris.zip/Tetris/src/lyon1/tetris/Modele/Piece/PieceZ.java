package lyon1.tetris.Modele.Piece;

import java.awt.Color;
import java.awt.Point;

public class PieceZ extends Piece{
	
	public PieceZ() {
		super(Color.RED);
		blocs=new Point[] {new Point(0,0), new Point(1,0), new Point(1,1), new Point(2,1)};
	}

	@Override
	public void deplacerGauche() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deplacerDroite() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void descendre() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rotation() {
		// TODO Auto-generated method stub
		
	}

}
