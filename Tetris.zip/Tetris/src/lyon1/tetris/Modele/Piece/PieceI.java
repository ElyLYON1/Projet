package lyon1.tetris.Modele.Piece;

import java.awt.Color;
import java.awt.Point;

public class PieceI extends Piece{
	
	
	public PieceI() {
		
		super(Color.CYAN);
		blocs=new Point[]{new Point(0, 0),new Point(0, 1), new Point(0, 2), new Point(0, 3)};
		
	}

	@Override
	public void deplacerGauche() {
		for (Point point : blocs) {
            point.x--; // Déplacer chaque bloc vers la gauche
        }		
	}

	@Override
	public void deplacerDroite() {
		for (Point point : blocs) {
            point.x++; // Déplacer chaque bloc vers la gauche
        }		
	}

	@Override
	public void descendre() {
		for (Point point : blocs) {
            point.y--; // Déplacer chaque bloc vers la gauche
        }		
	}

	@Override
	public void rotation() {
		// TODO Auto-generated method stub
		
	}
	
	

	
}
